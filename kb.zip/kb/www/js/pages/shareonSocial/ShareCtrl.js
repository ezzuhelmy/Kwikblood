'use strict';

angular.module('kwikblood')

    .controller('ShareCtrl',['$scope',function($scope) {
    $scope.whatsappShare=function(){
        window.plugins.socialsharing.shareViaWhatsApp('Join the community for blood donators - KwikBlood', null, 'http://fb.me/kwikblood', null, function(errormsg){alert("Error: Cannot Share")});
    }
    $scope.twitterShare=function(){
        window.plugins.socialsharing.shareViaTwitter('Join the community for blood donators - KwikBlood', null, 'http://fb.me/kwikblood', null, function(errormsg){alert("Error: Cannot Share")});
    }
    $scope.facebookShare=function(){
        window.plugins.socialsharing.shareViaFacebook('Join the community for blood donators - KwikBlood', null, 'http://fb.me/kwikblood', null, function(errormsg){alert("Error: Cannot Share")});
    }
    $scope.OtherShare=function(){
        window.plugins.socialsharing.share('Join the community for blood donators - KwikBlood', null,null, 'http://fb.me/kwikblood');
    }
    
    }])

