'use strict';

angular.module('kwikblood')
    .config(function ($stateProvider) {
      $stateProvider
          .state('app.changePass', {
            url: '/changePass',
            templateUrl: "templates/changePass.html",
            controller: 'ChangePassCtrl'
          });
    });