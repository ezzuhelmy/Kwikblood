'use strict';

angular.module('kwikblood')

  // Define the Login Controller
  .controller('LoginCtrl', function ($scope, FURL, Auth, $location, toaster) {

     $scope.signedIn = Auth.signedIn; 
      
    // Don't allow login if you are logged in
    if (Auth.signedIn()) {
      toaster.pop('error', "Please logout before attempting to login");
      // If logged in, redirect to the home page
      $location.path('/profile');
    }

    $scope.loginFb = function () {
      Auth.loginFacebook();
    };

    $scope.loginGl = function () {
      Auth.loginGoogle();
    };

    $scope.loginTw = function () {
      Auth.loginTwitter();
    };

    $scope.loginGb = function () {
      Auth.loginGithub();
    };

    $scope.isApple = Auth.isApple;

    $scope.login = function (user) {
      Auth.login(user);
      user.email = '';
      user.password = '';
    };
    
    $scope.logout = function () {
      toaster.pop('success', "Logged out successfully");
      Auth.logout();
      $location.path('/login');
    }

  });
