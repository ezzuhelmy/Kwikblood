'use strict';

angular.module('kwikblood')
    .config(function ($stateProvider) {
      $stateProvider
          .state('app.admin', {
            url: '/admin',
            views: {
              'menuContent': {
                templateUrl: "templates/admin.html",
                controller: 'AdminCtrl'
              }
            }
          });
    });